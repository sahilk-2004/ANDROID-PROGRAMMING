package com.example.gamelistanimals

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    private val animals = listOf(
        "Lion", "Tiger", "Elephant", "Giraffe", "Zebra",
        "Kangaroo", "Panda", "Cheetah", "Monkey", "Deer"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val linearLayout = findViewById<LinearLayout>(R.id.linearLayoutAnimals)

        // Dynamically adding animal list items
        for (animal in animals) {
            val textView = TextView(this)
            textView.text = animal
            textView.textSize = 18f
            textView.setPadding(20, 10, 20, 10)
            linearLayout.addView(textView)
        }
    }
}
