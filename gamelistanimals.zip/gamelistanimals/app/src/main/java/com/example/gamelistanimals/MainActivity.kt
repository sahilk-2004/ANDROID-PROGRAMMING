package com.example.gamelistanimals

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val games = listOf(
        "Chess", "Football", "Cricket", "Basketball", "Tennis",
        "Hockey", "Badminton", "Volleyball", "Table Tennis", "Golf"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val linearLayout = findViewById<LinearLayout>(R.id.linearLayoutGames)

        // Dynamically adding game list items
        for (game in games) {
            val textView = TextView(this)
            textView.text = game
            textView.textSize = 18f
            textView.setPadding(20, 10, 20, 10)
            linearLayout.addView(textView)
        }

        // Button to navigate to SecondActivity (Animals List)
        val btnNext = findViewById<Button>(R.id.btnNext)
        btnNext.setOnClickListener {
            startActivity(Intent(this, SecondActivity::class.java))
        }
    }
}
