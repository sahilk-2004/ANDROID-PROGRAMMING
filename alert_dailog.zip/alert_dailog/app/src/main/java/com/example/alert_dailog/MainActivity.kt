package com.example.alert_dailog

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // Show Alert Dialog when Back button is pressed
    override fun onBackPressed() {
        val alertDialog = AlertDialog.Builder(this)
        alertDialog.setTitle("Exit App")
        alertDialog.setMessage("Are you sure you want to exit?")

        alertDialog.setPositiveButton("Yes") { _, _ ->
            super.onBackPressed() // Exit the app
        }

        alertDialog.setNegativeButton("No") { dialog, _ ->
            dialog.dismiss() // Close the dialog and stay in the app
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }

        alertDialog.setCancelable(false) // Prevent closing dialog by tapping outside
        alertDialog.show()
    }
}