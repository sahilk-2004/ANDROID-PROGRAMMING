package com.example.prac_calc

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var editText: EditText
    private var input = StringBuilder()
    private var operator = ""
    private var num1 = 0.0
    private var num2 = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editText = findViewById(R.id.editText)
    }

    fun onDigitClick(view: View) {
        val button = view as Button
        input.append(button.text.toString())
        editText.setText(input.toString())
    }

    fun onOperatorClick(view: View) {
        val button = view as Button
        if (input.isNotEmpty()) {
            num1 = input.toString().toDouble()
            operator = button.text.toString()
            input.clear()
        }
    }

    fun onEqualClick(view: View) {
        if (input.isNotEmpty()) {
            num2 = input.toString().toDouble()
            val result = when (operator) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "X" -> num1 * num2
                "/" -> if (num2 != 0.0) num1 / num2 else {
                    editText.setText("Error")
                    return
                }
                "%" -> num1 % num2
                else -> 0.0
            }
            editText.setText(result.toString())
            input.clear()
        }
    }

    fun onClearClick(view: View) {
        input.clear()
        editText.setText("")
    }

    fun onDeleteClick(view: View) {
        if (input.isNotEmpty()) {
            input.deleteCharAt(input.length - 1)
            editText.setText(input.toString())
        }
    }
}
